THE DESIGN LOFT INTERIORS - WEBSITE UPLOAD GUIDE
================================================

WHAT IS IN THIS FOLDER
  index.html     the website (this is the home page)
  reviews.json   approved client comments shown in "The Client Perspective"
  images/        all photos
  video/         the landing page video

HOW TO PUT IT ON YOUR DOMAIN
  Upload everything INSIDE this folder (not the folder itself) to the main
  folder of your hosting, usually called  public_html  or  www.
  Keep the folder structure exactly as it is. index.html must sit at the top.
  Ways to upload: your hosting's File Manager (cPanel / hPanel: Upload, or
  upload the .zip and choose Extract), or an FTP program such as FileZilla.

  Simple alternative: Netlify or Cloudflare Pages - drag this folder onto the
  page, then add your domain in their Domain settings.

MAKING THE FORMS WORK (feedback + start-your-project form)
  By default both forms open the visitor's email app, addressed to
  hello@thedesignloft.ae. To receive messages directly in your inbox instead:
    1. Create a free form at https://formspree.io (use hello@thedesignloft.ae).
    2. Copy the form address, it looks like  https://formspree.io/f/abcdwxyz
    3. Open index.html in a text editor, find the line
           window.TDL={formEndpoint:""};
       and paste the address between the quotes. Save and upload again.

SHOWING CLIENT REVIEWS ON THE WEBSITE
  Feedback arrives in your email. Review it, and add the ones you approve to
  reviews.json in this format (one block per review, comma between blocks):

  [
    { "name": "Client name", "rating": 5, "text": "Their comment here." },
    { "name": "Another client", "rating": 4, "text": "Another comment." }
  ]

  rating is a number from 1 to 5 (stars). name may be left as "".
  Upload the updated reviews.json. The slider arrows appear automatically
  once there are two or more reviews.

NOTES
  - Turn on HTTPS / SSL in your hosting panel (free on most hosts).
  - The page loads its fonts from Google Fonts, so visitors need internet.
